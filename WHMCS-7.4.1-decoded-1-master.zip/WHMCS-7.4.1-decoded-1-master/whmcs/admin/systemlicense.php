<?php 
define("ROUTE_CONVERTED_LEGACY_ENDPOINT", true);
$_GET["rp"] = "/admin/help/license";
require_once(__DIR__ . "/index.php");

