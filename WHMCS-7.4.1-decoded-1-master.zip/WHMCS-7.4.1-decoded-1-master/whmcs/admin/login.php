<?php 
define("ROUTE_CONVERTED_LEGACY_ENDPOINT", true);
$_GET["rp"] = "/admin/login";
require_once(__DIR__ . "/index.php");

